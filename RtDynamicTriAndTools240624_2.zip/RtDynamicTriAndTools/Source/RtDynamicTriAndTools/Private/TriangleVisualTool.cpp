// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.


#include "TriangleVisualTool.h"
#include "Components/StaticMeshComponent.h"

#include "FTriVisualSceneProxy.h"
#include "TriangleMathLibrary.h"
#include "TriangleAndTetrahedron.h"
#include "Engine/StaticMesh.h"
//#include "Interfaces/IPluginManager.h"
#include "Kismet/KismetMathLibrary.h"
//#include "UTriangleMathLibrary.h"
#include "VectorTypes.h"
#include "Kismet/KismetMaterialLibrary.h"
#include "Materials/MaterialInstanceDynamic.h"


//UTriVisualTool
UTriVisualTool::UTriVisualTool( const FObjectInitializer& ObjectInitializer )
	: Super( ObjectInitializer )
{
	PrimaryComponentTick.bCanEverTick = false;

	SetCollisionProfileName(UCollisionProfile::BlockAllDynamic_ProfileName);
}

int UTriVisualTool::AddTriangle(const F3DSpaceTriangle& Triangle, const bool bWorldSpace, const FLinearColor Color, const FTriangleAttribute Attributes)
{
	//Return -1 indicates creation failure.
	if(!Triangle.IsTriangleValid(1e-5)) return -1;

	//If the three points of the triangle passed in are in world coordinates, they need to be converted to local coordinates relative to the component.
	F3DSpaceTriangle LocalTriangle;
	if(!bWorldSpace) { LocalTriangle = Triangle; }
	else
	{
		LocalTriangle = Triangle.InverseTransform(GetComponentTransform());
	}

	//Add to render the triangle.
	const int Index = Tris.Add(FVisualTriangle(LocalTriangle,FTriangleVerticesColor(Color),FProxyTriangleAttribute(Attributes.bWireframe)));
	
	//Initial Material
	if(UMaterialInterface* Material = Cast<UMaterialInterface>(StaticLoadObject(UMaterialInterface::StaticClass(),nullptr,*FPropertyNames::MatPath)))
	{
		SetMaterial(Index,Material);
		UMaterialInstanceDynamic* DynamicMaterial = CreateDynamicMaterialInstance(Index);
		
		UpdateMaterialPointsValue(DynamicMaterial,LocalTriangle);
		UpdateMaterialColorsValue(DynamicMaterial,FTriangleVerticesColor(Color));
		UpdateMaterialAttributesValue(DynamicMaterial,Attributes);
	}
	MarkRenderStateDirty();
	UpdateBounds();
	
	return Index;
}

TArray<int> UTriVisualTool::AddTriangles(const TArray<F3DSpaceTriangle>& Triangle, const bool bWorldSpace,
                                         const FLinearColor Color, const FTriangleAttribute Attributes)
{
	TArray<int> TrianglesIndex;
	//使用AddUninitialized预先分配一次内存, 分配内存比较昂贵,在循环外部执行, 循环内设置元素.
	const int AddTriangleNum = Triangle.Num();
	TrianglesIndex.SetNumUninitialized(AddTriangleNum);
	
	const int NowTriangleNum = Tris.Num();
	Tris.AddUninitialized(AddTriangleNum);

	UMaterialInterface* Material = Cast<UMaterialInterface>(StaticLoadObject(UMaterialInterface::StaticClass(),nullptr,*FPropertyNames::MatPath));

	int CurrentIndexToOperate = 0;
	for(int i = 0; i < AddTriangleNum; ++i)
	{
		if(!Triangle[i].IsTriangleValid(1e-5))
		{
			//RemoveAtSwap:移除并使最后一位替换过来,而不是逐个前移, 由于后边都是空元素, 使用此节省性能
			//当移除时, 下一次循环仍需在当前位置操作,而不使用下一位, 故填入CurrentIndexToOperate
#if ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION == 4
			TrianglesIndex.RemoveAtSwap(CurrentIndexToOperate,EAllowShrinking::No);
			Tris.RemoveAtSwap(NowTriangleNum+CurrentIndexToOperate,EAllowShrinking::No);
#elif ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION <= 3
			TrianglesIndex.RemoveAtSwap(CurrentIndexToOperate);
			Tris.RemoveAtSwap(NowTriangleNum+CurrentIndexToOperate);
#endif
		}
		else
		{
			F3DSpaceTriangle LocalTriangle;
			if(!bWorldSpace) { LocalTriangle = Triangle[i]; }
			else
			{
				LocalTriangle = Triangle[i].InverseTransform(GetComponentTransform());
			}
			Tris[NowTriangleNum +CurrentIndexToOperate] = FVisualTriangle(LocalTriangle,FTriangleVerticesColor(Color),FProxyTriangleAttribute(Attributes.bWireframe));
			TrianglesIndex[CurrentIndexToOperate] = NowTriangleNum +CurrentIndexToOperate;
			
			if( Material != nullptr )
			{
				SetMaterial(NowTriangleNum +CurrentIndexToOperate,Material);
				UMaterialInstanceDynamic* DynamicMaterial = CreateDynamicMaterialInstance(NowTriangleNum +CurrentIndexToOperate);
				
				UpdateMaterialPointsValue(DynamicMaterial,LocalTriangle);
				UpdateMaterialColorsValue(DynamicMaterial,FTriangleVerticesColor(Color));
				UpdateMaterialAttributesValue(DynamicMaterial,Attributes);
			}
			//添加成功, 该位置被占用, 当前索引+1
			++CurrentIndexToOperate;
		}
	}
#if ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION == 4
	TrianglesIndex.Shrink();
	Tris.Shrink();
#endif
	
	MarkRenderStateDirty();
	UpdateBounds();
	
	return TrianglesIndex;
}

bool UTriVisualTool::RemoveTriangle(const int Index)
{
	bool Success = false;
	if(Tris.IsValidIndex(Index))
	{
		//Tris[Index]->DestroyComponent();
		Tris.RemoveAtSwap(Index);
		Success = true;
	}
	//需把对应材质也移除, 没有现成的API
	//首先获取所有 不包括index的材质
	TArray<UMaterialInterface*> OutMaterials = GetMaterials();
	if(OutMaterials.IsValidIndex(Index))
	{
		OutMaterials.RemoveAtSwap(Index);
	}
	//清空材质s
	EmptyOverrideMaterials();
	//重新设置材质
	for(int i = 0; i < OutMaterials.Num(); ++i)
	{
		SetMaterial(i,OutMaterials[i]);
	}
	
	MarkRenderStateDirty();
	UpdateBounds();
	return Success;
}

void UTriVisualTool::RemoveTriangles(const TArray<int> IndexArray)
{
	const int RemoveNum = IndexArray.Num();
	TArray<UMaterialInterface*> OutMaterials = GetMaterials();
	for(int i = 0; i < RemoveNum; ++i)
	{
		
#if ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION == 4
		if(Tris.IsValidIndex(IndexArray[i]))
		{
			Tris.RemoveAt(IndexArray[i],EAllowShrinking::No);
		}
		if(OutMaterials.IsValidIndex(IndexArray[i]))
		{
			OutMaterials.RemoveAt(IndexArray[i],EAllowShrinking::No);
		}
#elif ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION <= 3
		if(Tris.IsValidIndex(IndexArray[i]))
		{
			Tris.RemoveAt(IndexArray[i]);
		}
		if(OutMaterials.IsValidIndex(IndexArray[i]))
		{
			OutMaterials.RemoveAt(IndexArray[i]);
		}
#endif
	}
#if ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION == 4
	Tris.Shrink();
	OutMaterials.Shrink();
#endif
	
	EmptyOverrideMaterials();

	for(int i = 0; i < OutMaterials.Num(); ++i)
	{
		SetMaterial(i,OutMaterials[i]);
	}
	
	MarkRenderStateDirty();
	UpdateBounds();
}

void UTriVisualTool::RemoveAllTriangles()
{
	//清空材质
	EmptyOverrideMaterials();
	//清空三角面
	Tris.Reset();
	
	MarkRenderStateDirty();
	UpdateBounds();
}

F3DSpaceTriangle UTriVisualTool::GetTriangle(const int Index, const bool bWorldSpace) const
{
	if(Tris.IsValidIndex(Index))
	{
		if(const UMaterialInstanceDynamic* Material = Cast<UMaterialInstanceDynamic>(GetMaterial(Index)))
		{
			FLinearColor PointA_PointBColor;
			FLinearColor PointCColor;
			
			Material->GetVectorParameterValue(FMaterialParameterInfo(FPropertyNames::PointA_PointB),PointA_PointBColor);
			Material->GetVectorParameterValue(FMaterialParameterInfo(FPropertyNames::PointC),PointCColor);
			
			const FVector PointA = FVector(PointA_PointBColor.R,PointA_PointBColor.G,0)*FVector(1,-1,1);
			const FVector PointB = FVector(PointA_PointBColor.B,PointA_PointBColor.A,0)*FVector(1,-1,1);
			const FVector PointC = UKismetMathLibrary::Conv_LinearColorToVector(PointCColor)*FVector(1,-1,1);
		
			const F3DSpaceTriangle Triangle = F3DSpaceTriangle(PointA,PointB,PointC).Transform(Tris[Index].VerticesPosition.MakeTransform());
			if(!bWorldSpace){ return Triangle;}
			return Triangle.InverseTransform(GetComponentTransform());
		}
	}
	return F3DSpaceTriangle(0);
}

TArray<F3DSpaceTriangle> UTriVisualTool::GetTriangles(const TArray<int> IndexArray, const bool bWorldSpace) const
{
	TArray<F3DSpaceTriangle> TrianglesArray;
	TrianglesArray.AddUninitialized(IndexArray.Num());
	for(int i = 0; i < IndexArray.Num(); ++i)
	{
		TrianglesArray[i] = GetTriangle(IndexArray[i],bWorldSpace);
	}
	return TrianglesArray;
}

TArray<int> UTriVisualTool::GetAllTrianglesIndexArray() const
{
	if(Tris.Num() == 0)
	{
		return TArray<int>{-1};
	}
	TArray<int> Triangles;
	Triangles.AddUninitialized(Tris.Num());
	
	for(int i = 0; i < Tris.Num(); ++i)
	{
		Triangles[i] = i;
	}
	return Triangles;
}

bool UTriVisualTool::UpdateTriangle(const int Index, const F3DSpaceTriangle& Triangle, const bool bWorldSpace)
{
	if(Tris.IsValidIndex(Index) && Triangle.IsTriangleValid(1e-5))
	{
		F3DSpaceTriangle LocalTriangle;
		if(!bWorldSpace) { LocalTriangle = Triangle; }
		else
		{
			LocalTriangle = Triangle.InverseTransform(GetComponentTransform());
		}
		Tris[Index].VerticesPosition = F3DSpaceTriangle(LocalTriangle);
		//Tris[Index]->SetRelativeTransform(LocalTriangle.MakeTransform());
		if(UMaterialInstanceDynamic* DynamicMaterial = Cast<UMaterialInstanceDynamic>(GetMaterial(Index)))
		{
			UpdateMaterialPointsValue(DynamicMaterial,LocalTriangle);
		}
		MarkRenderStateDirty();
		UpdateBounds();
	}
	return false;
}

void UTriVisualTool::UpdateTriangles(const TArray<int> IndexArray, const TArray<F3DSpaceTriangle>& TrianglesArray,
	const bool bWorldSpace)
{
	const int ExecuteNum = FMath::Min(IndexArray.Num(),TrianglesArray.Num());
	for(int i = 0; i < ExecuteNum; ++i)
	{
		if(Tris.IsValidIndex(i) && TrianglesArray[i].IsTriangleValid(1e-5))
		{
			F3DSpaceTriangle LocalTriangle;
			if(!bWorldSpace) { LocalTriangle = TrianglesArray[i]; }
			else
			{
				LocalTriangle = TrianglesArray[i].InverseTransform(GetComponentTransform());
			}
			Tris[i].VerticesPosition = F3DSpaceTriangle(LocalTriangle);
			if(UMaterialInstanceDynamic* DynamicMaterial = Cast<UMaterialInstanceDynamic>(GetMaterial(i)))
			{
				UpdateMaterialPointsValue(DynamicMaterial,LocalTriangle);
			}
		}
	}
	MarkRenderStateDirty();
	UpdateBounds();
}

bool UTriVisualTool::GetTriangleAttributes(const int Index, FTriangleAttribute& Attributes) const
{
	Attributes = FTriangleAttribute();
	if(Tris.IsValidIndex(Index))
	{
		if(const UMaterialInstanceDynamic* DynamicMaterial = Cast<UMaterialInstanceDynamic>(GetMaterial(Index)))
		{
			float fWireframe;
			DynamicMaterial->GetScalarParameterValue(FMaterialParameterInfo(FPropertyNames::Wireframe),fWireframe);
			Attributes.bWireframe = fWireframe > .5f ? true : false;
			
			DynamicMaterial->GetScalarParameterValue(FMaterialParameterInfo(FPropertyNames::Blur),Attributes.Blur);
			//DynamicMaterial->GetScalarParameterValue(FMaterialParameterInfo(FPropertyNames::Alpha),Attributes.Alpha);
			DynamicMaterial->GetScalarParameterValue(FMaterialParameterInfo(FPropertyNames::Emissive),Attributes.Emissive);
			//VerticesColor = Tris[Index].Colors;
		}
	}
	return false;
}

void UTriVisualTool::SetTriangleAttributes(const int Index,const FTriangleAttribute Attributes)
{
	if(Tris.IsValidIndex(Index))
	{
		Tris[Index].Attribute.bWireframe = Attributes.bWireframe;
		if(UMaterialInstanceDynamic* DynamicMaterial = Cast<UMaterialInstanceDynamic>(GetMaterial(Index)))
		{
			UpdateMaterialAttributesValue(DynamicMaterial,Attributes);
		}
	}
	MarkRenderStateDirty();
//	UpdateBounds();
}

void UTriVisualTool::SetAllTrianglesAttributes(const FTriangleAttribute Attributes)
{
	for(UMaterialInterface* Material : GetMaterials())
	{
		if(UMaterialInstanceDynamic* DynamicMaterial = Cast<UMaterialInstanceDynamic>(Material))
		{
			UpdateMaterialAttributesValue(DynamicMaterial,Attributes);
		}
	}
	const int TrisNum = Tris.Num();
	for(int i = 0; i < TrisNum; ++i)
	{
		Tris[i].Attribute.bWireframe = Attributes.bWireframe;
	}
	MarkRenderStateDirty();
	//UpdateBounds();
}

bool UTriVisualTool::SetTriangleColorModel(const int Index, const EColorModel ColorModel, const FTriangleVerticesColor VerticesColor)
{
	if(Tris.IsValidIndex(Index))
	{
		Tris[Index].Colors = VerticesColor;
		if(UMaterialInstanceDynamic* DynamicMaterial = Cast<UMaterialInstanceDynamic>(GetMaterial(Index)))
		{
			UpdateMaterialColorsValue(DynamicMaterial,VerticesColor);
			switch (ColorModel)
			{
			case EColorModel::RadialCoordinates:
				DynamicMaterial->SetScalarParameterValue(FPropertyNames::ColorModel,0.f);
				break;
			case EColorModel::LinerDistance:
				DynamicMaterial->SetScalarParameterValue(FPropertyNames::ColorModel,.5f);
				break;
			case EColorModel::VertexColor:
				DynamicMaterial->SetScalarParameterValue(FPropertyNames::ColorModel,1.f);
				break;
			}
		}
		MarkRenderStateDirty();
		//UpdateBounds();
		
		return true;
	}
	return false;
}

void UTriVisualTool::SetAllTrianglesColorModel(const EColorModel ColorModel, const FTriangleVerticesColor VerticesColor)
{
	const int TrisNum = Tris.Num();
	for(int i = 0; i < TrisNum; ++i)
	{
		Tris[i].Colors = VerticesColor;
		if(UMaterialInstanceDynamic* DynamicMaterial = Cast<UMaterialInstanceDynamic>(GetMaterial(i)))
		{
			UpdateMaterialColorsValue(DynamicMaterial,VerticesColor);
			switch (ColorModel)
			{
			case EColorModel::RadialCoordinates:
				DynamicMaterial->SetScalarParameterValue(FPropertyNames::ColorModel,0.f);
				break;
			case EColorModel::LinerDistance:
				DynamicMaterial->SetScalarParameterValue(FPropertyNames::ColorModel,.5f);
				break;
			case EColorModel::VertexColor:
				DynamicMaterial->SetScalarParameterValue(FPropertyNames::ColorModel,1.f);
				break;
			}
		}
	}
	MarkRenderStateDirty();
	//UpdateBounds();
}

bool UTriVisualTool::AddTriangleVerticesOffset(const int Index, const F3DSpaceTriangle Offset, const bool bWorldSpace)
{
	F3DSpaceTriangle LocalOffset;
	if(!bWorldSpace) { LocalOffset = Offset; }
	else
	{
		//Offset, 位移, 其中的每个分量都应视为向量, 而不是具体点位, 故应InverseTransformVector, 而非position.
		//LocalOffset = Offset.InverseTransform(GetComponentTransform());
		LocalOffset.A = GetComponentTransform().InverseTransformVector(Offset.A);
		LocalOffset.B = GetComponentTransform().InverseTransformVector(Offset.B);
		LocalOffset.C = GetComponentTransform().InverseTransformVector(Offset.C);
	}
	if(Tris.IsValidIndex(Index))
	{
		Tris[Index].VerticesPosition += LocalOffset;
		
		if(UMaterialInstanceDynamic* DynamicMaterial = Cast<UMaterialInstanceDynamic>(GetMaterial(Index)))
		{
			UpdateMaterialPointsValue(DynamicMaterial,Tris[Index].VerticesPosition);
		}
		MarkRenderStateDirty();
		UpdateBounds();
		return true;
	}
	return false;
}

/*bool UTriVisualTool::SetTriangleUVModel(const int Index,const FVector2D Density,const FVector2D Offset, const EUVModel UVModel)
{
	if(Tris.IsValidIndex(Index))
	{
		if(UMaterialInstanceDynamic* Material = Cast<UMaterialInstanceDynamic>(GetMaterial(Index)))
		{
			const FLinearColor UVTiling = FLinearColor(Density.X,Density.Y,Offset.X,Offset.Y);
			Material->SetVectorParameterValue(FPropertyNames::UVTiling,UVTiling);
			switch (UVModel)
			{
			case EUVModel::Raw:
				Material->SetScalarParameterValue(FPropertyNames::RawUV,1);
				break;
			case EUVModel::RadialAndSlope:
				Material->SetScalarParameterValue(FPropertyNames::RawUV,0);
				break;
			}
			return true;
		}
	}
	return false;
}*/


void UTriVisualTool::UpdateMaterialPointsValue(UMaterialInstanceDynamic* InMaterial, const F3DSpaceTriangle& NewTri)
{
	//使用自己的transform, 逆向自己的位置, 将得到3点映射到平面的坐标
	const F3DSpaceTriangle TempTri = NewTri.InverseTransform(NewTri.MakeTransform());
    			
	const FLinearColor PointA_PointBColor = FLinearColor(TempTri.A.X,-TempTri.A.Y,TempTri.B.X,-TempTri.B.Y);
    const FLinearColor PointCColor = UKismetMathLibrary::Conv_VectorToLinearColor(TempTri.C*FVector(1,-1,1));
	
	InMaterial->SetVectorParameterValue(FPropertyNames::PointA_PointB,PointA_PointBColor);
    InMaterial->SetVectorParameterValue(FPropertyNames::PointC,PointCColor);
	
}

void UTriVisualTool::UpdateMaterialColorsValue(UMaterialInstanceDynamic* InMaterial, const FTriangleVerticesColor& Colors)
{
	InMaterial->SetVectorParameterValue(FPropertyNames::ColorA,Colors.PointAColor);
	InMaterial->SetVectorParameterValue(FPropertyNames::ColorB,Colors.PointBColor);
	InMaterial->SetVectorParameterValue(FPropertyNames::ColorC,Colors.PointCColor);
}

void UTriVisualTool::UpdateMaterialAttributesValue(UMaterialInstanceDynamic* InMaterial,const FTriangleAttribute& Attributes)
{
	InMaterial->SetScalarParameterValue(FPropertyNames::Wireframe,Attributes.bWireframe);
	InMaterial->SetScalarParameterValue(FPropertyNames::Blur,Attributes.Blur);
	InMaterial->SetScalarParameterValue(FPropertyNames::Emissive,Attributes.Emissive);
}

FPrimitiveSceneProxy* UTriVisualTool::CreateSceneProxy()
{
	FPrimitiveSceneProxy* Proxy = nullptr;
	if(Tris.Num() > 0)
	{
		Proxy = new FTriVisualSceneProxy(this);
	}
	return Proxy;
}

int32 UTriVisualTool::GetNumMaterials() const
{
	return OverrideMaterials.Num();
}

FBoxSphereBounds UTriVisualTool::CalcBounds(const FTransform& LocalToWorld) const
{
	FBox BoundingBox(ForceInit);

	// Bounds are tighter if the box is generated from pre-transformed vertices.
	for (int32 Index = 0; Index < Tris.Num(); ++Index)
	{
		BoundingBox += LocalToWorld.TransformPosition(Tris[Index].VerticesPosition.A);
		BoundingBox += LocalToWorld.TransformPosition(Tris[Index].VerticesPosition.B);
		BoundingBox += LocalToWorld.TransformPosition(Tris[Index].VerticesPosition.C);
	}

	FBoxSphereBounds NewBounds;
	NewBounds.BoxExtent = BoundingBox.GetExtent();
	NewBounds.Origin = BoundingBox.GetCenter();
	NewBounds.SphereRadius = NewBounds.BoxExtent.Size();

	return NewBounds;
}