﻿// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.

#include "TriangleAndTetrahedron.h"

//struct F3DSpaceTriangle

F3DSpaceTriangle::F3DSpaceTriangle(const FVector& Vertex0, const FVector& Vertex1, const FVector& Vertex2)
{
	A = Vertex0;
	B = Vertex1;
	C = Vertex2;
	bHas3IndVertices = true;
}

F3DSpaceTriangle::F3DSpaceTriangle(const TArray<FVector>& Vertices)
{
	//first test this condition, because it is most possible.
	if(Vertices.Num() >= 3)
	{
		A = Vertices[0];
		B = Vertices[1];
		C = Vertices[2];
		bHas3IndVertices = true;
	}
	else if(Vertices.Num() == 0)
	{
		A = FVector::ZeroVector;
		B = FVector::ZeroVector;
		C = FVector::ZeroVector;
		bHas3IndVertices = false;
	}
	else if(Vertices.Num() < 3)
	{
		A = Vertices[0];
		B = Vertices.Last();
		//C shouldn't be zero , it is will create a wrong triangle.
		C = A;
		bHas3IndVertices = false;
	}
	
}

bool F3DSpaceTriangle::IsTriangleValid(const double Threshold) const
{
	if(!bHas3IndVertices) return false;
	if(FVector::PointsAreNear(A,C,0.0001)
	|| FVector::PointsAreNear(B,C,0.0001)
	|| FVector::PointsAreNear(B,A,0.0001)) return false;
	
	return FVector::CrossProduct(B - A, C - A).SizeSquared() > Threshold * 1e5;
}

FVector F3DSpaceTriangle::GetNormal() const
{
	//这里只是公式, 不应该在这里判断三角形是否有效, 无论如何都需要计算出结果, 若崩溃, 在崩溃处判断有效性
	//以下同理
	return FVector::CrossProduct(C - A, GetTangent()).GetSafeNormal(0.001);
}

FVector F3DSpaceTriangle::GetTangent() const
{
	return (B - A).GetSafeNormal(0.001);
}

FVector F3DSpaceTriangle::GetBinormal() const
{
	return FVector::CrossProduct(GetTangent(),GetNormal()).GetSafeNormal(0.001);
}

double F3DSpaceTriangle::DistToPoint(const FVector& Point) const
{
	return FMath::Abs(FVector::PointPlaneDist(Point,A,GetNormal()));
}

FRotator F3DSpaceTriangle::MakeRotationFromOriAndOneSide(const bool FlipOri) const
{
	const FVector Normal = FlipOri ? -GetNormal() : GetNormal();
	return FRotationMatrix::MakeFromXZ(GetTangent(),Normal).Rotator();
}

FTransform F3DSpaceTriangle::MakeTransform() const
{
	FVector Circumcenter;
	FVector Orientation;
	double Radius;
	GetCircumcircle(Circumcenter,Orientation,Radius);
	
	const FQuat Quarternion = FQuat(MakeRotationFromOriAndOneSide());
	//构造大5倍, 避免边缘被削
	const FVector Scale3D = FVector(Radius);
	
	return FTransform(Quarternion,Circumcenter,Scale3D);
}

double F3DSpaceTriangle::GetArea() const
{
	const double LenBC = FVector::Dist(C,B);
	const double LenAC = FVector::Dist(C,A);
	const double LenAB = FVector::Dist(B,A);
	
	/*Heron's formula*/
	const double  SemiPerimeter = (LenBC + LenAC + LenAB) / 2;
	return FMath::Sqrt(SemiPerimeter * (SemiPerimeter - LenBC) * (SemiPerimeter - LenAC) * (SemiPerimeter - LenAB));
}

void F3DSpaceTriangle::GetIncircle(FVector& Incenter, FVector& Orientation, double& Radius) const
{
	const double LenBC = FVector::Dist(C,B);
	const double LenAC = FVector::Dist(C,A);
	const double LenAB = FVector::Dist(B,A);
	
	const double SumLen = LenBC + LenAC + LenAB;

	for(UINT i = 0; i < 3 ; ++i)
	{
		Incenter[i] = (LenBC * A[i] + LenAC * B[i] + LenAB * C[i]) / SumLen;
	}
	
	Orientation = GetNormal();

	Radius = 2 * GetArea() / SumLen;
}

void F3DSpaceTriangle::GetCircumcircle(FVector& Circumcenter, FVector& Orientation, double& Radius) const
{
	const FVector NormalAN = GetNormal();

	/*Coordinate channels of pointA*/
	const double X1 = A.X;
	const double Y1 = A.Y;
	const double Z1 = A.Z;
	/*Coordinate channels of pointB*/
	const double X2 = B.X;
	const double Y2 = B.Y;
	const double Z2 = B.Z;
	/*Coordinate channels of pointC*/
	const double X3 = C.X;
	const double Y3 = C.Y;
	const double Z3 = C.Z;

	/*
	 * Condition1.The circumcenter is equidistant from the three vertices of a triangle.
	 * Condition2.The line connecting the circumcenter to any vertex of the triangle is perpendicular to the normal.
	 * Equation(Set as Circumcenter -> O(H,I,J)):
	 * //@TODO: distance(OA) = distance(OB)
	 * -> (O.X-A.X)^2 + (O.Y-A.Y)^2 + (O.Z-A.Z)^2 = (O.X-B.X)^2 + (O.Y-B.Y)^2 + (O.Z-B.Z)^2;
	 * ->H^2-2HX1+X1^2 + I^2-2IY1+Y1^2 + J^2-2JZ1+Z1^2 = H^2-2HX2+X2^2 + I^2-2IY2+Y2^2 + J^2-2JZ2+Z2^2 ;
	 * ->X1^2 + Y1^2 + Z1^2 - X2^2 - Y2^2 - Z2^2 = 2HX1 + 2IY1 + 2JZ1 - 2HX2 - 2IY2 - 2JZ2;
	 * ->X1^2 + Y1^2 + Z1^2 - X2^2 - Y2^2 - Z2^2 = 2H(X1-X2) + 2I(Y1-Y2) + 2J(Z1-Z2);
	 * -----------------------------------------      ------      ------      ------
	 *                  S1                =         H*  D1  +  I*   E1   +  J*  F1
	 * //@TODO: distance(OA) = distance(OC) -> ......
	 * ->X1^2 + Y1^2 + Z1^2 - X3^2 - Y3^2 - Z3^2 = 2H(X1-X3) + 2I(Y1-Y3) + 2J(Z1-Z3);
	 * -----------------------------------------      ------      ------      ------
	 *                  S2                =         H*  D2  +  I*   E2   +  J*  F2
	 * //@TODO: Point-Normal Equation : (A.X - H) * NormalAN.X  + (A.Y - J) * NormalAN.Y + (A.Z - K)* NormalAN.Z = 0 
	 * ......Similarly, extract HJK...... 
	 * -> X1 * NormalAN.X + Y1 * NormalAN.Y + Z1 * NormalAN.Z = H * NormalAN.X + J * NormalAN.Y + K * NormalAN.Z;
	 * ------------------------------------------------------       ----------       ----------       ----------
	 *                  S3                =                     H*     D3     +   J*    E3      +  K*    F3
	 */
	//Create variables.
	const double D1 = 2 * (X1 - X2);
	const double E1 = 2 * (Y1 - Y2);
	const double F1 = 2 * (Z1 - Z2);
	const double D2 = 2 * (X1 - X3);
	const double E2 = 2 * (Y1 - Y3);
	const double F2 = 2 * (Z1 - Z3);
	const double D3 = NormalAN.X;
	const double E3 = NormalAN.Y;
	const double F3 = NormalAN.Z;
	const double S1 = X1 * X1 - X2 * X2 + Y1 * Y1 - Y2 * Y2 + Z1 * Z1 - Z2 * Z2;
	const double S2 = X1 * X1 - X3 * X3 + Y1 * Y1 - Y3 * Y3 + Z1 * Z1 - Z3 * Z3;
	const double S3 = X1 * D3 + Y1 * E3 + Z1 * F3;

	/* Now the equation system is:        solve by Kramer's rule
	S1 = D1 * x0 + E1 * y0 + F1 * z0;     D1 + E1 + F1     S1
	S2 = D2 * x0 + E2 * y0 + F2 * z0; ->  D2 + E2 + F2  =  S2
	S3 = D3 * x0 + E3 * y0 + F3 * z0;     D3 + E3 + F3     S3
	*/
	
	const double M = D1 * E2 * F3 + E1 * F2 * D3 + F1 * D2 * E3 - F1 * E2 * D3 - E1 * D2 * F3 - D1 * F2 * E3;
	const double N1 = S1 * E2 * F3 + E1 * F2 * S3 + F1 * S2 * E3 - F1 * E2 * S3 - E1 * S2 * F3 - S1 * F2 * E3;
	const double N2 = D1 * S2 * F3 + S1 * F2 * D3 + F1 * D2 * S3 - F1 * S2 * D3 - S1 * D2 * F3 - D1 * F2 * S3;
	const double N3 = D1 * E2 * S3 + E1 * S2 * D3 + S1 * D2 * E3 - S1 * E2 * D3 - E1 * D2 * S3 - D1 * S2 * E3;

	Circumcenter[0] = N1 / M;
	Circumcenter[1] = N2 / M;
	Circumcenter[2] = N3 / M;

	Orientation = NormalAN;
	
	Radius = FVector::Dist(A, Circumcenter);
}

F3DSpaceTriangle F3DSpaceTriangle::Transform(const FTransform& Transform) const
{
	return F3DSpaceTriangle(
		Transform.TransformPosition(A),
		Transform.TransformPosition(B),
		Transform.TransformPosition(C));
}

F3DSpaceTriangle F3DSpaceTriangle::InverseTransform(const FTransform& Transform) const
{
	return F3DSpaceTriangle(
		Transform.InverseTransformPosition(A),
		Transform.InverseTransformPosition(B),
		Transform.InverseTransformPosition(C));
}

//struct FTetrahedron
FTetrahedron::FTetrahedron(const FVector& Vertex0, const FVector& Vertex1, const FVector& Vertex2,const FVector& Vertex3)
{
	A = Vertex0;
	B = Vertex1;
	C = Vertex2;
	D = Vertex3;
	bHas4IndVertices = true;
}

FTetrahedron::FTetrahedron(const TArray<FVector>& Vertices)
{
	//first test this condition, because it is most possible.
	if(Vertices.Num() >= 4)
	{
		A = Vertices[0];
		B = Vertices[1];
		C = Vertices[2];
		D = Vertices[3];
		bHas4IndVertices = true;
	}
	else if(Vertices.Num() == 0)
	{
		A = FVector::ZeroVector;
		B = FVector::ZeroVector;
		C = FVector::ZeroVector;
		D = FVector::ZeroVector;
		bHas4IndVertices = false;
	}
	else if(Vertices.Num() < 4)
	{
		A = Vertices[0];
		//B = Vertices[1];
		B = Vertices.Last();
		//D shouldn't be zero , it is will create a wrong triangle.
		C = A;
		D = Vertices.Num()==3 ? Vertices[1] : A;
		bHas4IndVertices = false;
	}
}

bool FTetrahedron::IsATetrahedron(const double Threshold) const
{
	if(!bHas4IndVertices) return false;

	const F3DSpaceTriangle TriangleABC(A,B,C);

	if(!TriangleABC.IsTriangleValid()) return false;
	
	if(FVector::PointsAreNear(A,D,0.0001)
	|| FVector::PointsAreNear(B,D,0.0001)
	|| FVector::PointsAreNear(C,D,0.0001)) return false;

	const FVector NormalAN = TriangleABC.GetNormal();

	const double Value = FMath::Abs((A.X - D.X) * NormalAN.X  + (A.Y - D.Y) * NormalAN.Y + (A.Z - D.Z)* NormalAN.Z);

	return Value > Threshold;
}

double FTetrahedron::GetVolume() const
{
	return FMath::Abs(FVector::DotProduct((A-D),FVector::CrossProduct((B-A),(C-A)))) / 6;
}

void FTetrahedron::Get4Face(TArray<F3DSpaceTriangle>& InTriangle) const
{
	InTriangle.Add(F3DSpaceTriangle(A,B,C));
	InTriangle.Add(F3DSpaceTriangle(B,C,D));
	InTriangle.Add(F3DSpaceTriangle(C,D,A));
	InTriangle.Add(F3DSpaceTriangle(D,A,B));
}

void FTetrahedron::GetInsphere(FVector& Incenter, double& Radius) const
{
	//@todo:If the distance from a point to four planes is equal, that point is the incenter of the Tetrahedron.
	/* The computational complexity of this formula is relatively high.
	 *DistanceA = Abs(Dot(P - A,CrossProduct(B-A, C-B))) / CrossProduct(B-A, C-B).Length();
	 *->Abs(Dot(P - A,CrossProduct(AB, BC))) / CrossProduct(AB, BC).Length();
	 *->Abs(Dot(P - A,CrossProductA)) / CrossProductA.Length();
	 *->Abs(Dot(P - A,CrossProductA)) / CP_A_L;
	 *->Abs(Dot(((P.X - A.X ,P.Y - A.Y ,P.Z - A.Z)),CP_A)) / CP_A_L;
	 *->Abs((P.X - A.X)*CP_A.X + (P.Y - A.Y)*CP_A.Y + (P.Z - A.Z)*CP_A.Z) / CP_A_L
	 *
	 *DistanceB = Abs(Dot(P - B,CrossProduct(BC, CD))) / CrossProduct(BC, CD).Length();
	 *DistanceC = Abs(Dot(P - C,CrossProduct(CD, DA))) / CrossProduct(CD, DA).Length();
	 *DistanceD = Abs(Dot(P - D,CrossProduct(DA, AB))) / CrossProduct(DA, AB).Length();
	 *
	 *DistanceA == DistanceB;
	 *DistanceA == DistanceC;
	 *DistanceA == DistanceD;
	*/
	
	/*Using the FPlane structure and its method to calculate distance
	const FPlane P_A(A,B,C);
	const FPlane P_B(B,C,D);
	const FPlane P_C(C,D,A);
	const FPlane P_D(D,A,B);

	SET: Incenter(H,I,J)
 
	const double DistA = P_A.X * H + P_A.Y * I + P_A.Z * J - P_A.W;
	const double DistB = P_B.X * H + P_B.Y * I + P_B.Z * J - P_B.W;
	const double DistC = P_C.X * H + P_C.Y * I + P_C.Z * J - P_C.W;
	const double DistD = P_D.X * H + P_D.Y * I + P_D.Z * J - P_D.W;

	DistA = DistB ; DistA = DistC ; DistA = DistD ; //We need 3 Equation
	
	P_A.X * H + P_A.Y * I + P_A.Z * J - P_A.W = P_B.X * H + P_B.Y * I + P_B.Z * J - P_B.W;
	->(P_A.X - P_B.X) * H + (P_A.Y - P_B.Y) * I + (P_A.Z - P_B.Z) * J = P_A.W - P_B.W;
	->------------------    -------------------   ---------------------   --------------
	->     D1         * H  +      E1        * I   +       F1      * J  =      S1
	
	P_A.X * H + P_A.Y * I + P_A.Z * J - P_A.W = P_C.X * H + P_C.Y * I + P_C.Z * J - P_C.W;
	->(P_A.X - P_C.X) * H + (P_A.Y - P_C.Y) * I + (P_A.Z - P_C.Z) * J = P_A.W - P_C.W;
    ->------------------    -------------------   -------------------   --------------
    ->     D2         * H  +      E2        * I  +        F2      * J  =      S2
    
	P_A.X * H + P_A.Y * I + P_A.Z * J - P_A.W = P_D.X * H + P_D.Y * I + P_D.Z * J - P_D.W;
	->(P_A.X - P_D.X) * H + (P_A.Y - P_D.Y) * I + (P_A.Z - P_D.Z) * J = P_A.W - P_D.W;
    ->------------------    -------------------   -------------------   --------------
    ->     D3         * H  +      E3        * I   +       F3      * J  =      S3
	 */
	
	//@todo: The result of this distance formula is not necessarily a positive number (I did not include an absolute value expression),so the judgment result may not be correct.
	/*square both sides of the equation,the computational complexity of this formula is relatively high.
	 *(P_A.X * H + P_A.Y * I + P_A.Z * J - P_A.W)^2 ->
	 * P_A.X*H^2 + 2P_A.X*H*P_A.Y*I + 2P_A.X*H*P_A.Z*J − 2P_A.X*H*P_A.W + P_A.Y*I^2 + 2P_A.Y*I*P_A.Z*J−2P_A.Y*I*P_A.W + P_A.Z*J^2 − 2P_A.Z*J*P_A.W + P_A.W^2
	 */
		
	//@todo: Check the direction of the plane beforehand. If it is facing outwards, flip it, and then use the formula to calculate the distance.
	//The 0th position is constructed using (B, C, D) and lacks A. The same applies to other positions.
	TArray<FVector> Vertices{A,B,C,D};
	TArray<FPlane> Planes{FPlane(B,C,D),FPlane(C,D,A),FPlane(D,A,B),FPlane(A,B,C)};
	for(UINT i = 0 ; i < 4 ; ++i)
	{
		//Point A - Point A project to Plane(B,C,D) , is the direction of point A relative to Plane(B,C,D) ,OA
		if(const FVector ProjectAnotherPoint = (Vertices[i] - FPlane::PointPlaneProject(Vertices[i],Planes[i])).GetSafeNormal();
		//Plane(B,C,D)'s Normal · OA ,if < 0, flip plane ,ensure that all planes are facing inward.
			Planes[i].GetNormal().Dot(ProjectAnotherPoint) < 0)
		{
			Planes[i] = Planes[i].Flip();
		}
	}

	//construct the FPlane using the corrected direction of the plane.
	const FPlane P_A = Planes[3];
	const FPlane P_B = Planes[0];
	const FPlane P_C = Planes[1];
	const FPlane P_D = Planes[2];
	
	//Create variables.
	const double D1 = P_A.X - P_B.X;
	const double E1 = P_A.Y - P_B.Y;
	const double F1 = P_A.Z - P_B.Z;
	const double D2 = P_A.X - P_C.X;
	const double E2 = P_A.Y - P_C.Y;
	const double F2 = P_A.Z - P_C.Z;
	const double D3 = P_A.X - P_D.X;
	const double E3 = P_A.Y - P_D.Y;
	const double F3 = P_A.Z - P_D.Z;
	const double S1 = P_A.W - P_B.W;
	const double S2 = P_A.W - P_C.W;
	const double S3 = P_A.W - P_D.W;

	/* Now the equation system is:       solve by Kramer's rule
	S1 = D1 * x0 + E1 * y0 + F1 * z0;     D1 + E1 + F1     S1
	S2 = D2 * x0 + E2 * y0 + F2 * z0; ->  D2 + E2 + F2  =  S2
	S3 = D3 * x0 + E3 * y0 + F3 * z0;     D3 + E3 + F3     S3
	*/

	const double M = D1 * E2 * F3 + E1 * F2 * D3 + F1 * D2 * E3 - F1 * E2 * D3 - E1 * D2 * F3 - D1 * F2 * E3;
	const double N1 = S1 * E2 * F3 + E1 * F2 * S3 + F1 * S2 * E3 - F1 * E2 * S3 - E1 * S2 * F3 - S1 * F2 * E3;
	const double N2 = D1 * S2 * F3 + S1 * F2 * D3 + F1 * D2 * S3 - F1 * S2 * D3 - S1 * D2 * F3 - D1 * F2 * S3;
	const double N3 = D1 * E2 * S3 + E1 * S2 * D3 + S1 * D2 * E3 - S1 * E2 * D3 - E1 * D2 * S3 - D1 * S2 * E3;

	Incenter[0] = N1 / M;
	Incenter[1] = N2 / M;
	Incenter[2] = N3 / M;
	
	Radius = P_A.PlaneDot(Incenter);
}

void FTetrahedron::GetCircumsphere(FVector& Circumcenter, double& Radius) const
{
	/*Coordinate channels of pointA*/
	const double X1 = A.X;
	const double Y1 = A.Y;
	const double Z1 = A.Z;
	/*Coordinate channels of pointB*/
	const double X2 = B.X;
	const double Y2 = B.Y;
	const double Z2 = B.Z;
	/*Coordinate channels of pointC*/
	const double X3 = C.X;
	const double Y3 = C.Y;
	const double Z3 = C.Z;
	/*Coordinate channels of pointD*/
	const double X4 = D.X;
	const double Y4 = D.Y;
	const double Z4 = D.Z;
	
	/*
	* Condition.The circumcenter is equidistant from the three vertices of a triangular pyramid.
	* Equation(Set as Circumcenter -> O(H,I,J)):
	* //@TODO: distance(OA) = distance(OB)
	* -> (O.X-A.X)^2 + (O.Y-A.Y)^2 + (O.Z-A.Z)^2 = (O.X-B.X)^2 + (O.Y-B.Y)^2 + (O.Z-B.Z)^2;
	* ->H^2-2HX1+X1^2 + I^2-2IY1+Y1^2 + J^2-2JZ1+Z1^2 = H^2-2HX2+X2^2 + I^2-2IY2+Y2^2 + J^2-2JZ2+Z2^2 ;
	* ->X1^2 + Y1^2 + Z1^2 - X2^2 - Y2^2 - Z2^2 = 2HX1 + 2IY1 + 2JZ1 - 2HX2 - 2IY2 - 2JZ2;
	* ->X1^2 + Y1^2 + Z1^2 - X2^2 - Y2^2 - Z2^2 = 2H(X1-X2) + 2I(Y1-Y2) + 2J(Z1-Z2);
	* -----------------------------------------      ------      ------      ------
	*                  S1                =         H*  D1  +  I*   E1   +  J*  F1
	* //@TODO: distance(OA) = distance(OC) -> ......
	* ->X1^2 + Y1^2 + Z1^2 - X3^2 - Y3^2 - Z3^2 = 2H(X1-X3) + 2I(Y1-Y3) + 2J(Z1-Z3);
	* -----------------------------------------      ------      ------      ------
	*                  S2                =         H*  D2  +  I*   E2   +  J*  F2
	* //@TODO: distance(OA) = distance(OD) -> ......
	* ->X1^2 + Y1^2 + Z1^2 - X4^2 - Y4^2 - Z4^2 = 2H(X1-X4) + 2I(Y1-Y4) + 2J(Z1-Z4);
	* -----------------------------------------      ------      ------      ------
	*                  S3                =         H*  D3  +  I*   E3   +  J*  F3
	*/
	//Create variables.
	const double D1 = 2 * (X1 - X2);
	const double E1 = 2 * (Y1 - Y2);
	const double F1 = 2 * (Z1 - Z2);
	const double D2 = 2 * (X1 - X3);
	const double E2 = 2 * (Y1 - Y3);
	const double F2 = 2 * (Z1 - Z3);
	const double D3 = 2 * (X1 - X4);
	const double E3 = 2 * (Y1 - Y4);
	const double F3 = 2 * (Z1 - Z4);
	const double S1 = X1 * X1 - X2 * X2 + Y1 * Y1 - Y2 * Y2 + Z1 * Z1 - Z2 * Z2;
	const double S2 = X1 * X1 - X3 * X3 + Y1 * Y1 - Y3 * Y3 + Z1 * Z1 - Z3 * Z3;
	const double S3 = X1 * X1 - X4 * X4 + Y1 * Y1 - Y4 * Y4 + Z1 * Z1 - Z4 * Z4;

	/* Now the equation system is:       solve by Kramer's rule
	S1 = D1 * x0 + E1 * y0 + F1 * z0;     D1 + E1 + F1     S1
	S2 = D2 * x0 + E2 * y0 + F2 * z0; ->  D2 + E2 + F2  =  S2
	S3 = D3 * x0 + E3 * y0 + F3 * z0;     D3 + E3 + F3     S3
	*/
	
	const double M = D1 * E2 * F3 + E1 * F2 * D3 + F1 * D2 * E3 - F1 * E2 * D3 - E1 * D2 * F3 - D1 * F2 * E3;
	const double N1 = S1 * E2 * F3 + E1 * F2 * S3 + F1 * S2 * E3 - F1 * E2 * S3 - E1 * S2 * F3 - S1 * F2 * E3;
	const double N2 = D1 * S2 * F3 + S1 * F2 * D3 + F1 * D2 * S3 - F1 * S2 * D3 - S1 * D2 * F3 - D1 * F2 * S3;
	const double N3 = D1 * E2 * S3 + E1 * S2 * D3 + S1 * D2 * E3 - S1 * E2 * D3 - E1 * D2 * S3 - D1 * S2 * E3;

	Circumcenter[0] = N1 / M;
	Circumcenter[1] = N2 / M;
	Circumcenter[2] = N3 / M;

	Radius = FVector::Dist(A, Circumcenter);
}

FTetrahedron FTetrahedron::TransformLocation(const FTransform& Transform) const
{
	return FTetrahedron(
		Transform.TransformPosition(A),
		Transform.TransformPosition(B),
		Transform.TransformPosition(C),
		Transform.TransformPosition(D));
}

FTetrahedron FTetrahedron::InverseTransformLocation(const FTransform& Transform) const
{
	return FTetrahedron(
		Transform.InverseTransformPosition(A),
		Transform.InverseTransformPosition(B),
		Transform.InverseTransformPosition(C),
		Transform.InverseTransformPosition(D));
}