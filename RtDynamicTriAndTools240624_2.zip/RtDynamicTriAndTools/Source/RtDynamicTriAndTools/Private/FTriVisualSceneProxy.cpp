﻿// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.
#include "FTriVisualSceneProxy.h"
#include "TriangleAndTetrahedron.h"
#include "TriangleVisualTool.h"
#include "TriangleMathLibrary.h"
#include "Materials/MaterialRenderProxy.h"
#include "SceneInterface.h"
#include "Kismet/KismetMathLibrary.h"
#include "Materials/MaterialInterface.h"

FTriVisualSceneProxy::FTriVisualSceneProxy(UTriVisualTool* Component)
		: FPrimitiveSceneProxy(Component)
		, VertexFactory(GetScene().GetFeatureLevel(), "FTriVisualSceneProxy")
		, MaterialRelevance(Component->GetMaterialRelevance(GetScene().GetFeatureLevel()))
{
	//初始化TrisAttributes数组的容量, 模范原生写法
	TrisAttributes.AddUninitialized(Component->Tris.Num());
	
	//const FColor VertexColor(0,255,255);
	TArray<FDynamicMeshVertex> Vertices;
	const int32 NumTris = Component->Tris.Num();
	Vertices.AddUninitialized(NumTris * 3);
	IndexBuffer.Indices.AddUninitialized(NumTris * 3);
	// Add each triangle to the vertex/index buffer
	for(int32 TriIdx = 0; TriIdx < NumTris; TriIdx++)
	{
		//初始化TrisAttributes的每个元素
		TrisAttributes[TriIdx] = Component->Tris[TriIdx].Attribute;
		TrisAttributes[TriIdx].Material = Component->GetMaterial(TriIdx);
		
		FVisualTriangle& Tri = Component->Tris[TriIdx];
		F3DSpaceTriangle& VerticesPosition = Tri.VerticesPosition;

		F3DSpaceTriangle Tri2D_UV = VerticesPosition.InverseTransform(VerticesPosition.MakeTransform());
		
			
		const FVector TangentX = VerticesPosition.GetTangent();
		const FVector TangentZ = VerticesPosition.GetNormal();
		const FVector TangentY = VerticesPosition.GetBinormal();

		FDynamicMeshVertex Vert;
		//在这里设置顶点的UV
		//Vert.TextureCoordinate
		Vert.SetTangents((FVector3f)TangentX, (FVector3f)TangentY, (FVector3f)TangentZ);
		
		Vert.TextureCoordinate[0] = FVector2f(Tri2D_UV.A.X,Tri2D_UV.A.Y) / 2 + .5f;
		Vert.Color = Tri.Colors.PointAColor.ToFColor(false);
		Vert.Position = (FVector3f)VerticesPosition.A;
		Vertices[TriIdx * 3 + 0] = Vert;
		IndexBuffer.Indices[TriIdx * 3 + 0] = TriIdx * 3 + 0;
		
		Vert.TextureCoordinate[0] = FVector2f(Tri2D_UV.B.X,Tri2D_UV.B.Y) / 2 + .5f;
		Vert.Color = Tri.Colors.PointBColor.ToFColor(false);
		Vert.Position = (FVector3f)VerticesPosition.B;
		Vertices[TriIdx * 3 + 1] = Vert;
		IndexBuffer.Indices[TriIdx * 3 + 1] = TriIdx * 3 + 1;

		Vert.TextureCoordinate[0] = FVector2f(Tri2D_UV.C.X,Tri2D_UV.C.Y) / 2 + .5f;
		Vert.Color = Tri.Colors.PointCColor.ToFColor(false);
		Vert.Position = (FVector3f)VerticesPosition.C;
		Vertices[TriIdx * 3 + 2] = Vert;
		IndexBuffer.Indices[TriIdx * 3 + 2] = TriIdx * 3 + 2;
	}
	VertexBuffers.InitFromDynamicVertex(&VertexFactory, Vertices);
	//Debug::Print(VertexBuffers.PositionVertexBuffer.VertexPosition(0));
	// Enqueue initialization of render resource
	BeginInitResource(&VertexBuffers.PositionVertexBuffer);
	BeginInitResource(&VertexBuffers.StaticMeshVertexBuffer);
	BeginInitResource(&VertexBuffers.ColorVertexBuffer);
	BeginInitResource(&IndexBuffer);
	BeginInitResource(&VertexFactory);
	
}

FTriVisualSceneProxy::~FTriVisualSceneProxy()
{
	VertexBuffers.PositionVertexBuffer.ReleaseResource();
	VertexBuffers.StaticMeshVertexBuffer.ReleaseResource();
	VertexBuffers.ColorVertexBuffer.ReleaseResource();
	IndexBuffer.ReleaseResource();
	VertexFactory.ReleaseResource();
}

void FTriVisualSceneProxy::GetDynamicMeshElements(const TArray<const FSceneView*>& Views, const FSceneViewFamily& ViewFamily, uint32 VisibilityMap, FMeshElementCollector& Collector) const
{
	//该vis tool的全局变量, 不逐三角形修改的
	const bool bProxyIsSelected = IsSelected();
	const bool bProxyIsHovered = IsHovered();
	const bool bEngineWireframe = AllowDebugViewmodes() && ViewFamily.EngineShowFlags.Wireframe;
	
	//逐三角形创建 每次一个三角面
	for(int i = 0; i < TrisAttributes.Num(); ++i)
	{
		//逐三角形读取的变量
		const FColor TriColor = VertexBuffers.ColorVertexBuffer.VertexColor(i*3);
		const bool bTriWireframe = TrisAttributes[i].bWireframe;

		//如果引擎开启了线框视图, 创建一个纯色材质作为线框材质, 使用三角面A点作为纯色显示(自身的线框视图,原普通材质)
		FColoredMaterialRenderProxy* WireframeMaterialInstance = nullptr;
		if (bEngineWireframe)
		{
			//Debug::Print("bEngineWireframe, setColoredMaterialRenderProxy");
			WireframeMaterialInstance = new FColoredMaterialRenderProxy(
			GEngine->WireframeMaterial->GetRenderProxy(),
			GetSelectionColor(TriColor,!(GIsEditor && ViewFamily.EngineShowFlags.Selection) || bProxyIsSelected, bProxyIsHovered, false));
			
			Collector.RegisterOneFrameMaterialProxy(WireframeMaterialInstance);
		}

		//如果引擎开启了线框视图, 显示之前创建的材质, 否则, 使用自身材质.(自身的线框视图,也使用自身材质)
		const FMaterialRenderProxy* MaterialProxy = nullptr;
		if(bEngineWireframe)
		{
			MaterialProxy = WireframeMaterialInstance;
		}
		else
		{
			//当bTriWireframe为true(需显示线框)时, 使用的为该材质. 而当bEngineWireframe也为true(需显示线框)时, 将使用纯色材质
			//当bTriWireframe为true不设置FColoredMaterialRenderProxy, 有时会导致而当bEngineWireframe视图缺少三角形线框.
			//检查出现频率, 是否修复,(若不修复线框可以为彩色
			MaterialProxy = TrisAttributes[i].Material->GetRenderProxy();
		}

		//这是固定写法, 因为不一定只有一个窗口. 对每个视图渲染
		for (int32 ViewIndex = 0; ViewIndex < Views.Num(); ViewIndex++)
		{
			if (VisibilityMap & (1 << ViewIndex))
			{
				//这个没用到
				//const FSceneView* View = Views[ViewIndex];
				
				// Draw the mesh.
				FMeshBatch& Mesh = Collector.AllocateMesh();
				FMeshBatchElement& BatchElement = Mesh.Elements[0];
				BatchElement.IndexBuffer = &IndexBuffer;
				//是否渲染线框模式, 与材质无关
				Mesh.bWireframe = bTriWireframe || bEngineWireframe;
				Mesh.VertexFactory = &VertexFactory;
				//设置该面的材质, 已经在前边设置过MaterialProxy
				Mesh.MaterialRenderProxy = MaterialProxy;

				bool bHasPrecomputedVolumetricLightmap;
				FMatrix PreviousLocalToWorld;
				int32 SingleCaptureIndex;
				bool bOutputVelocity;
				GetScene().GetPrimitiveUniformShaderParameters_RenderThread(GetPrimitiveSceneInfo(), bHasPrecomputedVolumetricLightmap, PreviousLocalToWorld, SingleCaptureIndex, bOutputVelocity);
				bOutputVelocity |= AlwaysHasVelocity();

				FDynamicPrimitiveUniformBuffer& DynamicPrimitiveUniformBuffer = Collector.AllocateOneFrameResource<FDynamicPrimitiveUniformBuffer>();

#if ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION == 4
				DynamicPrimitiveUniformBuffer.Set(Collector.GetRHICommandList(), GetLocalToWorld(), PreviousLocalToWorld, GetBounds(), GetLocalBounds(), true, bHasPrecomputedVolumetricLightmap, bOutputVelocity);
#elif ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION <= 3
				DynamicPrimitiveUniformBuffer.Set(GetLocalToWorld(), PreviousLocalToWorld, GetBounds(), GetLocalBounds(), true, bHasPrecomputedVolumetricLightmap, bOutputVelocity);
#endif
				
				BatchElement.PrimitiveUniformBufferResource = &DynamicPrimitiveUniformBuffer.UniformBuffer;

				//若有n个顶点,从第几个开始渲染, 比如不渲染第一个(0,1,2), 就FirstIndex = 3;
				BatchElement.FirstIndex = i * 3;
				//该面片有几个基元, 对于此, 每次只渲一个三角面, 则设为1
				BatchElement.NumPrimitives = 1;
				//需核实到底是0-2, 还是按FirstIndex递增(3i, 3i+2)
				BatchElement.MinVertexIndex = i * 3+0;
				BatchElement.MaxVertexIndex = i * 3 + 2;
			
				Mesh.ReverseCulling = IsLocalToWorldDeterminantNegative();
				Mesh.Type = PT_TriangleList;
				Mesh.DepthPriorityGroup = SDPG_World;
				Mesh.bCanApplyViewModeOverrides = false;
				Collector.AddMesh(ViewIndex, Mesh);
			}
		}
	}
}

FPrimitiveViewRelevance FTriVisualSceneProxy::GetViewRelevance(const FSceneView* View) const
{
	FPrimitiveViewRelevance Result;
		
	Result.bDrawRelevance = IsShown(View);
	Result.bShadowRelevance = IsShadowCast(View);
	Result.bDynamicRelevance = true;
	Result.bRenderInMainPass = ShouldRenderInMainPass();
	Result.bUsesLightingChannels = GetLightingChannelMask() != GetDefaultLightingChannelMask();
	Result.bRenderCustomDepth = ShouldRenderCustomDepth();
	Result.bTranslucentSelfShadow = bCastVolumetricTranslucentShadow;
	MaterialRelevance.SetPrimitiveViewRelevance(Result);
	Result.bVelocityRelevance = DrawsVelocity() && Result.bOpaque && Result.bRenderInMainPass;
		
	return Result;
}

bool FTriVisualSceneProxy::CanBeOccluded() const
{
	return !MaterialRelevance.bDisableDepthTest;
}

uint32 FTriVisualSceneProxy::GetMemoryFootprint(void) const
{
	return(sizeof(*this) + GetAllocatedSize());
}