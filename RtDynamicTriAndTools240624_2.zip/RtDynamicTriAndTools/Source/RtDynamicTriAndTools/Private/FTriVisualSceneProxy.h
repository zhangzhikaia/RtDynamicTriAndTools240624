﻿// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.
#pragma once
#include "DynamicMeshBuilder.h"
#include "Materials/Material.h"
#include "MaterialDomain.h"
#include "PrimitiveSceneProxy.h"
#include "StaticMeshResources.h"

class UTriVisualTool;
class UMaterialInterface;

struct FProxyTriangleAttribute
{
	FProxyTriangleAttribute(){}
	explicit FProxyTriangleAttribute(const bool InbWireframe):bWireframe(InbWireframe){}
	//explicit FTriangleAttribute(const float InBlur):Blur(InBlur){}
	//explicit FTriangleAttribute(const bool InbWireframe,const float InBlur):bWireframe(InbWireframe),Blur(InBlur){}
	bool bWireframe = false;
	//float Blur = 0.f;
	TObjectPtr<UMaterialInterface> Material = UMaterial::GetDefaultMaterial(MD_Surface);
};

//I don't render triangles in there, it just use to set collision
class FTriVisualSceneProxy final : public FPrimitiveSceneProxy
{
public:
	SIZE_T GetTypeHash() const override
	{
		static size_t UniquePointer;
		return reinterpret_cast<size_t>(&UniquePointer);
	}
	explicit FTriVisualSceneProxy(UTriVisualTool* Component);
	
	virtual ~FTriVisualSceneProxy() override;

	virtual FPrimitiveViewRelevance GetViewRelevance(const FSceneView* View) const override;
	
	virtual void GetDynamicMeshElements(const TArray<const FSceneView*>& Views, const FSceneViewFamily& ViewFamily, uint32 VisibilityMap, FMeshElementCollector& Collector) const override;

	virtual bool CanBeOccluded() const override;

	virtual uint32 GetMemoryFootprint(void) const override;

	uint32 GetAllocatedSize(void) const
	{
		return(FPrimitiveSceneProxy::GetAllocatedSize());
	}
	
private:
	//UMaterialInterface* Material;
	FStaticMeshVertexBuffers VertexBuffers;
	FMaterialRelevance MaterialRelevance;
	FDynamicMeshIndexBuffer32 IndexBuffer;
	FLocalVertexFactory VertexFactory;

	TArray<FProxyTriangleAttribute> TrisAttributes;
};
