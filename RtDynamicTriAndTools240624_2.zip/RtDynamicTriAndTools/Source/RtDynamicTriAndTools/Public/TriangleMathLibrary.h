// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.

#pragma once

#include "CoreMinimal.h"
#include "Engine/Engine.h"
#include "Kismet/BlueprintFunctionLibrary.h"
//#include "Kismet/KismetStringLibrary.h"
#include "TriangleMathLibrary.generated.h"

/**
 * 
 */

#if 0
namespace Debug
{
	static void Print(const FString& message, FColor color = FColor::Blue)
	{
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 3, color, message);
		}
		UE_LOG(LogTemp,Warning,TEXT("%s"),*message);
	}
	static void Print(const int32& message, FColor color = FColor::Blue)
	{
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 3, color, FString::FromInt(message));
		}
		UE_LOG(LogTemp,Warning,TEXT("%i"),message);
	}
	static void Print(const double& message, FColor color = FColor::Blue)
	{
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 3, color, UKismetStringLibrary::Conv_DoubleToString(message));
		}
		UE_LOG(LogTemp,Warning,TEXT("%f"),message);
	}
	static void Print(const FText& message, FColor color = FColor::Blue)
	{
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 3, color, message.ToString());
		}
		UE_LOG(LogTemp,Warning,TEXT("%s"),*message.ToString());
	}
	static void Print(const FVector& InVector, FColor color = FColor::Blue)
	{
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 3, color, InVector.ToString());
		}
		UE_LOG(LogTemp,Warning,TEXT("%s"),*InVector.ToString());
	}
	static void Print(const FLinearColor& InColor, FColor color = FColor::Blue)
	{
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 3, color, InColor.ToString());
		}
		UE_LOG(LogTemp,Warning,TEXT("%s"),*InColor.ToString());
	}
	static void Print(const FVector3f& InVector, FColor color = FColor::Blue)
	{
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 3, color, InVector.ToString());
		}
		UE_LOG(LogTemp,Warning,TEXT("%s"),*InVector.ToString());
	}
	static void FastPrint()
	{
		Print(TEXT("FastPring : Debug"));
		UE_LOG(LogTemp,Warning,TEXT("FastPring : Debug"));
	}
}
#endif

struct F3DSpaceTriangle;
struct FTetrahedron;

UCLASS()
class RTDYNAMICTRIANDTOOLS_API UTriangleMathLibrary: public UBlueprintFunctionLibrary
{
	GENERATED_BODY()
	
	/**	Calculate the distance from a point to the plane containing a triangle.	*/
	UFUNCTION(BlueprintCallable, Category = "RtDynamicTriAndTools|Math", BlueprintPure)
	static double PointDistToTrianglePlane(const FVector& Point, const F3DSpaceTriangle& Triangle);

	/**
	 *	Is the triangle have three independent and non-collinear vertices.
	 *  @param 	Threshold  The larger the threshold, the easier it is to judge the points as collinear.
	 */
	UFUNCTION(BlueprintCallable, Category = "RtDynamicTriAndTools|Math", BlueprintPure)
	static bool IsTriangleValid(const F3DSpaceTriangle& Triangle,const double Threshold = 1);
	
	UFUNCTION(BlueprintCallable, Category = "RtDynamicTriAndTools|Tools", BlueprintPure)
	static TArray<F3DSpaceTriangle> GetTrianglesFromStaticMesh(const UStaticMesh* InMesh);

	/**
	 *  @param 	bUnique  Whether to consider duplicate vertices of adjacent triangular faces as a single vertex.
	 */
	UFUNCTION(BlueprintCallable, Category = "RtDynamicTriAndTools|Tools", BlueprintPure)
	static TArray<FVector3f> GetVerticesFromStaticMesh(const UStaticMesh* InMesh, const bool bUnique);

	/**
	 *	Compose a triangle from an array of three points.
	 *	@param Vertices The length of the array should be 3.
	 */
	UFUNCTION(BlueprintCallable, Category = "RtDynamicTriAndTools|Tools", BlueprintPure,meta=(CompactNodeTitle = "VerticesToTriangle"))
	static F3DSpaceTriangle PointArrayToTriangle(const TArray<FVector>& Vertices);
	
	/*
	UFUNCTION(BlueprintCallable, Category = "RtDynamicTriAndTools|Math", BlueprintPure)
	static bool Is3PointsAreNotCollinear(const TArray<FVector>& Vertices,const double Threshold = 1);*/
	
	UFUNCTION(BlueprintCallable, Category = "RtDynamicTriAndTools|Math", BlueprintPure)
	static void NormalTangentAndBinormalOfATriangle(FVector& Normal, FVector& Tangent, FVector& Binormal, const F3DSpaceTriangle& InTriangle);

	/**
	 *	Using the face orientation of a triangle and a vector representing one of its edges, form a rotation.
	 * @param FlipOri If using the opposite face orientation.
	 */
	UFUNCTION(BlueprintCallable, Category = "RtDynamicTriAndTools|Math", BlueprintPure)
    static FRotator MakeRotationFromOriAndOneSideOfATriangle(const F3DSpaceTriangle& Triangle, const bool FlipOri);

	UFUNCTION(BlueprintCallable, Category = "RtDynamicTriAndTools|Math", BlueprintPure)
	static double AreaOfATriangle(const F3DSpaceTriangle& Triangle);

	/**
	 *	Calculate the inscribed circle of a triangle.
	 *	@param Incenter The position of the incenter of the triangle.
	 *	@param Orientation Facing towards and perpendicular to the triangular face.
	 */
	UFUNCTION(BlueprintCallable, Category = "RtDynamicTriAndTools|Math", BlueprintPure)
	static void IncircleOfATriangle(FVector& Incenter, FVector& Orientation, double& Radius, const F3DSpaceTriangle& Triangle);

	/**
	 *	Calculating the circumcircle of a triangle.
	 *	@param Circumcenter The position of the circumcenter of the triangle.
	 *	@param Orientation Facing towards and perpendicular to the triangular face.
	 */
	UFUNCTION(BlueprintCallable, Category = "RtDynamicTriAndTools|Math", BlueprintPure)
	static void CircumcircleOfATriangle(FVector& Circumcenter, FVector& Orientation, double& Radius, const F3DSpaceTriangle& InTriangle);

	/** Transform the positions of the triangle's three vertices using the transform.*/
	UFUNCTION(BlueprintCallable, Category = "RtDynamicTriAndTools|Math", BlueprintPure)
	static F3DSpaceTriangle TransformTriangle(const F3DSpaceTriangle& InTriangle,const FTransform& Transform);

	/** Inverse transform the positions of the triangle's three vertices using the transform.*/
	UFUNCTION(BlueprintCallable, Category = "RtDynamicTriAndTools|Math", BlueprintPure)
	static F3DSpaceTriangle InverseTransformTriangle(const F3DSpaceTriangle& InTriangle,const FTransform& Transform);

	
	//Tetrahedron
	/**
	 *	Compose a tetrahedron from an array of four points.
	 *	@param Vertices The length of the array should be 4.
	 */
	UFUNCTION(BlueprintCallable, Category = "RtDynamicTriAndTools|Math", BlueprintPure,meta=(CompactNodeTitle = "VerticesToTetrahedron"))
	static FTetrahedron PointArrayToTetrahedron(const TArray<FVector>& Vertices);

	/**
	 *	Is the tetrahedron have four independent and non-coplanar vertices.
	 *  @param 	Threshold  The larger the threshold, the easier it is to judge the points as coplanar.
	 */
	UFUNCTION(BlueprintCallable, Category = "RtDynamicTriAndTools|Math", BlueprintPure)
	static bool IsTetrahedronValid(const FTetrahedron& InTetrahedron,const double Threshold = 1);
	
	/*UFUNCTION(BlueprintCallable, Category = "RtDynamicTriAndTools|Math", BlueprintPure,
	meta=(ToolTip="When the number of input points is less than 4, consider as coplanar; else if greater than 4, calculate the first four."))
	static bool Is4PointsAreNotCoplanar(const TArray<FVector>& Vertices, const double Threshold = 1);*/

	UFUNCTION(BlueprintCallable, Category = "RtDynamicTriAndTools|Math", BlueprintPure)
	static double VolumeOfATetrahedron(const FTetrahedron& InTetrahedron);
	
	UFUNCTION(BlueprintCallable, Category = "RtDynamicTriAndTools|Math", BlueprintPure)
	static void InsphereOfATetrahedron(FVector& Incenter, double& Radius, const FTetrahedron& InTetrahedron);
	
	UFUNCTION(BlueprintCallable, Category = "RtDynamicTriAndTools|Math", BlueprintPure)
	static void CircumsphereOfATetrahedron(FVector& Circumcenter, double& Radius, const FTetrahedron& InTetrahedron);

	UFUNCTION(BlueprintCallable, Category = "RtDynamicTriAndTools|Math", BlueprintPure,meta=(CompactNodeTitle = "TetrahedronToTriangles"))
	static void TetrahedronTo4Triangle(const FTetrahedron& InTetrahedron,TArray<F3DSpaceTriangle>& InTriangle);

	UFUNCTION(BlueprintCallable, Category = "RtDynamicTriAndTools|Math", BlueprintPure)
	static FTetrahedron TransformTetrahedron(const FTetrahedron& InTetrahedron,const FTransform& Transform);

	UFUNCTION(BlueprintCallable, Category = "RtDynamicTriAndTools|Math", BlueprintPure)
	static FTetrahedron InverseTransformTetrahedron(const FTetrahedron& InTetrahedron,const FTransform& Transform);
};
