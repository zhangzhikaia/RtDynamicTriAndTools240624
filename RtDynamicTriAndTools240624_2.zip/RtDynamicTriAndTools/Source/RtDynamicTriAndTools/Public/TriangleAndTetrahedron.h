﻿// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.

#pragma once

#include "CoreMinimal.h"  
//#include "UObject/ObjectMacros.h"
#include "TriangleAndTetrahedron.generated.h"

USTRUCT(BlueprintType)
struct F3DSpaceTriangle
{
	GENERATED_USTRUCT_BODY()
	
	F3DSpaceTriangle(){}
	
	//Construct an invalid triangle
	explicit F3DSpaceTriangle(const int InV){bHas3IndVertices = false;}
	
	explicit F3DSpaceTriangle(const FVector& Vertex0,const FVector& Vertex1,const FVector& Vertex2);
	explicit F3DSpaceTriangle(const TArray<FVector>& Vertices);
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category=Triangle)
	FVector A = FVector::ZeroVector;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category=Triangle)
	FVector B = FVector::ZeroVector;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category=Triangle)
	FVector C = FVector::ZeroVector;

private:
	//Determining whether a triangle is valid requires a certain amount of calculation,
	//but sometimes it is already determined to be invalid during the construction process, so it is preserved here,
	//Avoid unnecessary calculations.
	bool bHas3IndVertices = true;
	
public:
	F3DSpaceTriangle operator+(const F3DSpaceTriangle& Other) const {  
		F3DSpaceTriangle Result;  
		Result.A = this->A + Other.A;
		Result.B = this->B + Other.B;
		Result.C = this->C + Other.C;
		return Result;  
	}
	F3DSpaceTriangle& operator+=(const F3DSpaceTriangle& Other) {  
		this->A += Other.A;
		this->B += Other.B;
		this->C += Other.C;
		return *this; 
	}  

	//Is3PointsAreNotCollinear
	bool IsTriangleValid(const double Threshold = 1) const;

	FVector GetNormal() const;

	FVector GetTangent() const;

	FVector GetBinormal() const;

//	void GetNormalTangentAndBinormal(FVector& Normal,FVector& Tangent,FVector& Binormal) const;

	double DistToPoint(const FVector& Point) const;

	FRotator MakeRotationFromOriAndOneSide(const bool FlipOri = false) const;

	FTransform MakeTransform() const;

	double GetArea() const;

	void GetIncircle(FVector& Incenter, FVector& Orientation, double& Radius) const;

	void GetCircumcircle(FVector& Circumcenter, FVector& Orientation, double& Radius) const;

	F3DSpaceTriangle Transform(const FTransform& Transform) const;

	F3DSpaceTriangle InverseTransform(const FTransform& Transform) const;
};

USTRUCT(BlueprintType)
struct FTetrahedron
{
	GENERATED_USTRUCT_BODY()
	FTetrahedron(){}
	explicit FTetrahedron(const int InV){bHas4IndVertices = false;}
	explicit FTetrahedron(const FVector& Vertex0,const FVector& Vertex1,const FVector& Vertex2,const FVector& Vertex3);
	explicit FTetrahedron(const TArray<FVector>& Vertices);
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category=Tetrahedron)
	FVector A = FVector::ZeroVector;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category=Tetrahedron)
	FVector B = FVector::ZeroVector;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category=Tetrahedron)
	FVector C = FVector::ZeroVector;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category=Tetrahedron)
	FVector D = FVector::ZeroVector;

private:
	bool bHas4IndVertices = true;

public:
	//Is4PointsAreNotCoplanar
	bool IsATetrahedron(const double Threshold = 1) const;

	double GetVolume() const;

	void Get4Face(TArray<F3DSpaceTriangle>& InTriangle) const;

	void GetInsphere(FVector& Incenter, double& Radius) const;

	void GetCircumsphere(FVector& Circumcenter, double& Radius) const;

	FTetrahedron TransformLocation(const FTransform& Transform) const;

	FTetrahedron InverseTransformLocation(const FTransform& Transform) const;

};