// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.

#pragma once

#include "CoreMinimal.h"
#include "Components/MeshComponent.h"
#include "TriangleAndTetrahedron.h"
#include "FTriVisualSceneProxy.h"
//#include "UObject/ObjectMacros.h"
#include "Math/MathFwd.h"
#include "TriangleVisualTool.generated.h"

/**
 * 
 */

USTRUCT(BlueprintType)
struct FTriangleVerticesColor
{
	GENERATED_USTRUCT_BODY()
	FTriangleVerticesColor(){}
	explicit FTriangleVerticesColor(const FLinearColor& InColor):
	PointAColor(InColor),PointBColor(InColor),PointCColor(InColor){}
		
	explicit FTriangleVerticesColor(const FLinearColor& Vertex0Color,const FLinearColor& Vertex1Color,const FLinearColor& Vertex2Color):
	PointAColor(Vertex0Color),PointBColor(Vertex1Color),PointCColor(Vertex2Color){}
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category=TriangleColor)
	FLinearColor PointAColor = FLinearColor::White;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category=TriangleColor)
	FLinearColor PointBColor = FLinearColor::White;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category=TriangleColor)
	FLinearColor PointCColor = FLinearColor::White;
};

USTRUCT(BlueprintType)
struct FTriangleAttribute
{
	GENERATED_USTRUCT_BODY()
	FTriangleAttribute(){}
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TriangleAttribute")  
	bool bWireframe = false;  
  
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TriangleAttribute", meta = (ClampMinValue = "0.0", ClampMaxValue = "1.0"))  
	float Blur = 0.f;  
  
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TriangleAttribute", meta = (ClampMinValue = "0.0"))  
	float Emissive = 0.f;  
};

//用于向proxy 传递属性 , triangle attribute不需要全部传递过去, 使用FProxyTriangleAttribute传递, 其他都把原结构体传递
struct FVisualTriangle
{
	FVisualTriangle(){}
	
	explicit FVisualTriangle(const F3DSpaceTriangle& VerticesPosition):
	VerticesPosition(VerticesPosition){}

	explicit FVisualTriangle(const F3DSpaceTriangle& VerticesPosition,const FTriangleVerticesColor& InColor):
	VerticesPosition(VerticesPosition),Colors(InColor){}

	explicit FVisualTriangle(const F3DSpaceTriangle& VerticesPosition,const FProxyTriangleAttribute& InAttribute):
	VerticesPosition(VerticesPosition),Attribute(InAttribute){}

	explicit FVisualTriangle(const F3DSpaceTriangle& VerticesPosition,const FTriangleVerticesColor& InColor,const FProxyTriangleAttribute& InAttribute):
	VerticesPosition(VerticesPosition),Colors(InColor),Attribute(InAttribute){}
	
	F3DSpaceTriangle VerticesPosition = F3DSpaceTriangle();
	FTriangleVerticesColor Colors = FTriangleVerticesColor();
	FProxyTriangleAttribute Attribute = FProxyTriangleAttribute();
};

class FPropertyNames  
{  
public:
	//Vector Param
	static const inline FName PointA_PointB = FName(TEXT("PointA,B"));
	static const inline FName PointC = FName(TEXT("PointC"));
	//static const inline FName UVTiling = FName(TEXT("UVTiling"));
	
	static const inline FName ColorA = FName(TEXT("ColorA"));
	static const inline FName ColorB = FName(TEXT("ColorB"));
	static const inline FName ColorC = FName(TEXT("ColorC"));
	
	//Scalar Param
	static const inline FName Emissive = FName(TEXT("Emissive"));
	static const inline FName ColorModel = FName(TEXT("ColorModel"));
	//static const inline FName RawUV = FName(TEXT("RawUV"));
	static const inline FName Blur = FName(TEXT("Blur(DTAA)"));
	static const inline FName Wireframe = FName(TEXT("Wireframe"));
	//static const inline FName UseTexture = FName(TEXT("UseTexture"));

	//Texture Sample
	//static const inline FName TextureSample = FName(TEXT("TextureSample"));

	//Soft Path
	//static const inline FString MeshPath = TEXT("/Engine/BasicShapes/Plane");
	static const inline FString MatPath = TEXT("/RtDynamicTriAndTools/Materials/MI_TriangleMask");
  
private:  
	// 静态常量不应该有构造函数或析构函数  
	FPropertyNames() = delete;  
	~FPropertyNames() = delete;  
};

UENUM()
enum class EColorModel : uint8
{
	VertexColor,
	RadialCoordinates,
	LinerDistance
};

/*UENUM()
enum class EUVModel : uint8
{
	Raw,
	RadialAndSlope
};*/

UCLASS(meta=(BlueprintSpawnableComponent))
class RTDYNAMICTRIANDTOOLS_API UTriVisualTool : public UMeshComponent
{
	GENERATED_UCLASS_BODY()
	
	/**
	 * @param	bWorldSpace Is the input triangle constructed using three points in world positions (otherwise, it is in the actor's local space).
	 * @return  The index of the created triangle, or -1 if the creation failed (e.g., due to an invalid triangle).
	 */
	UFUNCTION(BlueprintCallable, Category="RtDynamicTriAndTools|Visual",meta=(Keywords = "Create Show a Triangle",AdvancedDisplay = "2"))
	int AddTriangle(const F3DSpaceTriangle& Triangle, const bool bWorldSpace = false,
	                const FLinearColor Color = FLinearColor::White, const FTriangleAttribute Attributes = FTriangleAttribute());
	
	/** When performing a large number of triangle addition operations, using this method is more efficient than executing individual operations through a loop in Blueprints.*/
	UFUNCTION(BlueprintCallable, Category="RtDynamicTriAndTools|Visual",meta=(Keywords = "Create Show Triangles",AdvancedDisplay = "2"))
	TArray<int> AddTriangles(const TArray<F3DSpaceTriangle>& Triangle, const bool bWorldSpace = false,
	                         const FLinearColor Color = FLinearColor::White, const FTriangleAttribute Attributes = FTriangleAttribute());
	
	UFUNCTION(BlueprintCallable, Category="RtDynamicTriAndTools|Visual",meta=(Keywords = "Delete a Triangle"))
	bool RemoveTriangle(const int Index);

	/** When performing a large number of triangle remove operations, using this method is more efficient than executing individual operations through a loop in Blueprints.*/
	UFUNCTION(BlueprintCallable, Category="RtDynamicTriAndTools|Visual",meta=(Keywords = "Delete Triangles"))
	void RemoveTriangles(const TArray<int> IndexArray);

	UFUNCTION(BlueprintCallable, Category="RtDynamicTriAndTools|Visual",meta=(Keywords = "clear triangles"))
	void RemoveAllTriangles();

	UFUNCTION(BlueprintCallable, Category="RtDynamicTriAndTools|Visual",BlueprintPure)
	F3DSpaceTriangle GetTriangle(const int Index, const bool bWorldSpace) const;

	UFUNCTION(BlueprintCallable, Category="RtDynamicTriAndTools|Visual",BlueprintPure)
	TArray<F3DSpaceTriangle> GetTriangles(const TArray<int> IndexArray, const bool bWorldSpace) const;

	/** If none, return TArray<int> {-1}*/
	UFUNCTION(BlueprintCallable, Category="RtDynamicTriAndTools|Visual",BlueprintPure)
	TArray<int> GetAllTrianglesIndexArray() const;
	
	/**
	 * Find the triangle in the array using the index,update it with the passed-in triangle.
	 *  @param	Triangle	Replace the triangle at the index with a new triangle.
	 *  @param	Index       The index of the triangle to be updated.
	 *  @param	bWorldSpace Is the input triangle constructed using three points in world positions (otherwise, it is in the actor's local space).
	 */
	UFUNCTION(BlueprintCallable, Category="RtDynamicTriAndTools|Visual",meta=(Keywords = "Set a Triangle"))
	bool UpdateTriangle(const int Index, const F3DSpaceTriangle& Triangle, const bool bWorldSpace);

	UFUNCTION(BlueprintCallable, Category="RtDynamicTriAndTools|Visual",meta=(Keywords = "Set Triangles"))
	void UpdateTriangles(const TArray<int> IndexArray, const TArray<F3DSpaceTriangle>& TrianglesArray, const bool bWorldSpace);

	/** Returns the values of all settable properties for a single triangle.*/
	UFUNCTION(BlueprintCallable, Category="RtDynamicTriAndTools|Visual")
	bool GetTriangleAttributes(const int Index, FTriangleAttribute& Attributes) const;

	UFUNCTION(BlueprintCallable, Category="RtDynamicTriAndTools|Visual")
	void SetTriangleAttributes(const int Index, const FTriangleAttribute Attributes=FTriangleAttribute());

	UFUNCTION(BlueprintCallable, Category="RtDynamicTriAndTools|Visual")
	void SetAllTrianglesAttributes(const FTriangleAttribute Attributes=FTriangleAttribute());
	
	UFUNCTION(BlueprintCallable, Category="RtDynamicTriAndTools|Visual")
	bool SetTriangleColorModel(const int Index, const EColorModel ColorModel= EColorModel::VertexColor, const FTriangleVerticesColor VerticesColor = FTriangleVerticesColor());

	UFUNCTION(BlueprintCallable, Category="RtDynamicTriAndTools|Visual")
	void SetAllTrianglesColorModel(const EColorModel ColorModel = EColorModel::VertexColor,const FTriangleVerticesColor VerticesColor = FTriangleVerticesColor());

	/*UFUNCTION(BlueprintCallable, Category="RtDynamicTriAndTools|Visual")
	bool SetTriangleUVModel(const int Index,const FVector2D Density,const FVector2D Offset, const EUVModel UVModel= EUVModel::Raw);
	*/
	UFUNCTION(BlueprintCallable, Category="RtDynamicTriAndTools|Visual")
	bool AddTriangleVerticesOffset(const int Index, const F3DSpaceTriangle Offset, const bool bWorldSpace = false);

	
private:
	static void UpdateMaterialPointsValue(UMaterialInstanceDynamic* InMaterial, const F3DSpaceTriangle& NewTri);

	static void UpdateMaterialColorsValue(UMaterialInstanceDynamic* InMaterial, const FTriangleVerticesColor& Colors);

	static void UpdateMaterialAttributesValue(UMaterialInstanceDynamic* InMaterial, const FTriangleAttribute& Attributes);
	
	//~ Begin UPrimitiveComponent Interface.
	virtual FPrimitiveSceneProxy* CreateSceneProxy() override;
	//~ End UPrimitiveComponent Interface.

	//~ Begin UMeshComponent Interface.
	virtual int32 GetNumMaterials() const override;
	//~ End UMeshComponent Interface.
	
	//~ Begin USceneComponent Interface.
	virtual FBoxSphereBounds CalcBounds(const FTransform& LocalToWorld) const override;
	//~ Begin USceneComponent Interface.
	
	TArray<FVisualTriangle> Tris;
	
	friend class FTriVisualSceneProxy;
};
