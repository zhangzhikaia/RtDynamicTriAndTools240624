// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.

#include "TriangleMathLibrary.h"
#include "Engine/StaticMesh.h"
#include "MeshDescription.h"
#include "StaticMeshAttributes.h"
#include "TriangleAndTetrahedron.h"


double UTriangleMathLibrary::PointDistToTrianglePlane(const FVector& Point, const F3DSpaceTriangle& Triangle)
{
	return Triangle.DistToPoint(Point);
}

bool UTriangleMathLibrary::IsTriangleValid(const F3DSpaceTriangle& Triangle,const double Threshold)
{
	return Triangle.IsTriangleValid(Threshold);
}

TArray<F3DSpaceTriangle> UTriangleMathLibrary::GetTrianglesFromStaticMesh(const UStaticMesh* InMesh)
{
	TArray<F3DSpaceTriangle> Triangles;
#if WITH_EDITOR
	if (InMesh->IsSourceModelValid(0))
	{
		if (!InMesh->GetSourceModel(0).IsRawMeshEmpty())
		{
			FMeshDescription* MeshDescription = InMesh->GetMeshDescription(0);
			TVertexAttributesConstRef<FVector3f> Positions = FStaticMeshConstAttributes(*MeshDescription).GetVertexPositions();
			TArray<FVector3f> PositionsArray;
			for(FVertexInstanceID VertexInstanceID : MeshDescription->VertexInstances().GetElementIDs())
			{
				FVertexID VertexID = MeshDescription->GetVertexInstanceVertex(VertexInstanceID);
				const FVector3f& Position = Positions[VertexID];
				PositionsArray.Add(Position);
			}
			const int TrisNum = PositionsArray.Num()/3;
			for(int i = 0; i < TrisNum; ++i)
			{
				const FVector A = FVector(PositionsArray[i*3]);
				const FVector B = FVector(PositionsArray[i*3+1]);
				const FVector C = FVector(PositionsArray[i*3+2]);
				
				Triangles.Add(F3DSpaceTriangle(A,B,C));
			}
		}
	}
#endif
	return Triangles;
}

TArray<FVector3f> UTriangleMathLibrary::GetVerticesFromStaticMesh(const UStaticMesh* InMesh, const bool bUnique)
{
	TArray<FVector3f> PositionsArray;
#if WITH_EDITOR
	if (InMesh->IsSourceModelValid(0))
	{
		if (!InMesh->GetSourceModel(0).IsRawMeshEmpty())
		{
			FMeshDescription* MeshDescription = InMesh->GetMeshDescription(0);
			TVertexAttributesConstRef<FVector3f> Positions = FStaticMeshConstAttributes(*MeshDescription).GetVertexPositions();
			
			for(FVertexInstanceID VertexInstanceID : MeshDescription->VertexInstances().GetElementIDs())
			{
				FVertexID VertexID = MeshDescription->GetVertexInstanceVertex(VertexInstanceID);
				//const FVector3f& Position = Positions[VertexID];
				bUnique ?
				PositionsArray.AddUnique(Positions[VertexID]):PositionsArray.Add(Positions[VertexID]);
			}
		}
	}
#endif
	return PositionsArray;
}

F3DSpaceTriangle UTriangleMathLibrary::PointArrayToTriangle(const TArray<FVector>& Vertices)
{
	if(Vertices.Num() < 3)
	{
		return F3DSpaceTriangle();
	}
	return F3DSpaceTriangle(Vertices);
}

void UTriangleMathLibrary::NormalTangentAndBinormalOfATriangle
(FVector& Normal, FVector& Tangent, FVector& Binormal,const F3DSpaceTriangle& InTriangle)
{
	Normal = InTriangle.GetNormal();
	Tangent = InTriangle.GetTangent();
	Binormal = InTriangle.GetBinormal();
}

FRotator UTriangleMathLibrary::MakeRotationFromOriAndOneSideOfATriangle(const F3DSpaceTriangle& Triangle,const bool FlipOri)
{
	return Triangle.MakeRotationFromOriAndOneSide(FlipOri);
}

double UTriangleMathLibrary::AreaOfATriangle(const F3DSpaceTriangle& Triangle)
{
	return Triangle.GetArea();
}

void UTriangleMathLibrary::IncircleOfATriangle(FVector& Incenter, FVector& Orientation, double& Radius, const F3DSpaceTriangle& Triangle)
{
	Triangle.GetIncircle(Incenter,Orientation,Radius);
}

void UTriangleMathLibrary::CircumcircleOfATriangle(FVector& Circumcenter, FVector& Orientation, double& Radius, const F3DSpaceTriangle& InTriangle)
{
	InTriangle.GetCircumcircle(Circumcenter,Orientation,Radius);
}

F3DSpaceTriangle UTriangleMathLibrary::TransformTriangle(const F3DSpaceTriangle& InTriangle,const FTransform& Transform)
{
	return InTriangle.Transform(Transform);
}

F3DSpaceTriangle UTriangleMathLibrary::InverseTransformTriangle(const F3DSpaceTriangle& InTriangle,const FTransform& Transform)
{
	return InTriangle.InverseTransform(Transform);
}

FTetrahedron UTriangleMathLibrary::PointArrayToTetrahedron(const TArray<FVector>& Vertices)
{
	return FTetrahedron(Vertices);
}

bool UTriangleMathLibrary::IsTetrahedronValid(const FTetrahedron& InTetrahedron, const double Threshold)
{
	return InTetrahedron.IsATetrahedron(Threshold);
}

double UTriangleMathLibrary::VolumeOfATetrahedron(const FTetrahedron& InTetrahedron)
{
	return InTetrahedron.GetVolume();
}

void UTriangleMathLibrary::InsphereOfATetrahedron(FVector& Incenter, double& Radius, const FTetrahedron& InTetrahedron)
{
	InTetrahedron.GetInsphere(Incenter,Radius);
}

void UTriangleMathLibrary::CircumsphereOfATetrahedron(FVector& Circumcenter, double& Radius, const FTetrahedron& InTetrahedron)
{
	InTetrahedron.GetCircumsphere(Circumcenter,Radius);
}

void UTriangleMathLibrary::TetrahedronTo4Triangle(const FTetrahedron& InTetrahedron,TArray<F3DSpaceTriangle>& InTriangle)
{
	InTetrahedron.Get4Face(InTriangle);
}

FTetrahedron UTriangleMathLibrary::TransformTetrahedron(const FTetrahedron& InTetrahedron,const FTransform& Transform)
{
	return InTetrahedron.TransformLocation(Transform);
}

FTetrahedron UTriangleMathLibrary::InverseTransformTetrahedron(const FTetrahedron& InTetrahedron,const FTransform& Transform)
{
	return InTetrahedron.InverseTransformLocation(Transform);
}
